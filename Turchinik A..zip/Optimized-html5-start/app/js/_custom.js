document.addEventListener("DOMContentLoaded", function() {


		$(".section-s1__slider").owlCarousel({
			items: 1,
			dots: false,
			nav:true,
			loop: true,
			navText: ['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>'],
			autoplay: true,
			autoplaySpeed: 800,
			autoHeight: true,
			autoplayTimeout: 10000
		});

		$(".real-slider").owlCarousel({
			items: 1,
			dots: false,
			nav:true,
			loop: true,
			navText: ['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>'],
			autoplay: true,
			autoplaySpeed: 1300,
			autoHeight: true,
			autoplayTimeout: 10000
		});


});
